package com.example.bmrcalculator;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class Information extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_infomation);
        final Button cal_btn = findViewById(R.id.Cal_button) ;
            cal_btn.setOnClickListener(new View.OnClickListener() {
                final EditText height_input =findViewById(R.id.height_input);
                final EditText weight_input =findViewById(R.id.weight_input);
                final EditText age_input =findViewById(R.id.age_input);
                final TextView bmr = findViewById(R.id.bmr);
                final RadioGroup radioGroup = findViewById(R.id.genderGroup);
                final RadioButton checkedRadio = findViewById(radioGroup.getCheckedRadioButtonId());
                @Override
                public void onClick(View v) {
                    double bmr_cal;
                    double weight = Double.parseDouble(weight_input.getText().toString());
                    double height = Double.parseDouble(height_input.getText().toString());
                    double age = Double.parseDouble(age_input.getText().toString());
                    if(checkedRadio.getText().equals("male")){
                        bmr_cal =66+(13.7*weight)+(5*height)-(6.8*age);
                    }else{
                        bmr_cal =665+(9.6*weight)+(1.8*height)-(4.7*age);
                    }

                    bmr.setText(Double.toString(bmr_cal));
                }
            }

            );
    }



}
