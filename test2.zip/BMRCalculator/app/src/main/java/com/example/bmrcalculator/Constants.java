package com.example.bmrcalculator;

public interface Constants {
    public static final String TABLE_NAME = "information";
    public static final String HEIGHT = "height";
    public static final String WEIGHT = "weight";
    public static final String BMR = "bmr";


}
